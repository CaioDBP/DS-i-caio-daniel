/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex5while;
import java.util.Scanner;
/**
 *
 * @author CAMARGO
 */
public class Ex5while {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int contador = 1;
        while (contador <= 10)
        {
            
        }
    }
    
}
