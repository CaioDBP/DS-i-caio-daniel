/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ex1while;

/**
 *
 * @author CAMARGO
 */
public class Ex1while {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero = 1;
        while (numero <=100)
        {
            if (numero % 2 !=0)
            {
                System.out.println(numero);
            }
            numero++;
        }
    }
    
}
