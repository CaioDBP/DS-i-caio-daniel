import java.util.Scanner;

public class exercicio4 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o código do produto: ");
        int codigoProduto = scanner.nextInt();

        System.out.print("Digite a quantidade: ");
        int quantidade = scanner.nextInt();

        double valorTotal = calcularValorTotal(codigoProduto, quantidade);

        System.out.printf("Valor a pagar: R$ %.2f", valorTotal);
    }

    private static double calcularValorTotal(int codigoProduto, int quantidade) {
        switch (codigoProduto) {
            case 100:
                return quantidade * 1.70;
            case 101:
                return quantidade * 2.30;
            case 102:
                return quantidade * 2.60;
            case 103:
                return quantidade * 2.40;
            case 104:
                return quantidade * 2.50;
            case 105:
                return quantidade * 1.00;
            default:
            
        }
    }
}
