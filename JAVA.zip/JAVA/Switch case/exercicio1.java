public class exercicio1 {

    public static String classificarProduto(int codigoProduto) {
        switch (codigoProduto) {
            case 1:
                return "Alimento não-perecível";
            case 2:
            case 3:
            case 4:
                return "Alimento perecível";
            case 5:
            case 6:
                return "Vestuário";
            case 7:
                return "Higiene Pessoal";
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
                return "Limpeza e Utensílios Domésticos";
            default:
                return "Código inválido";
        }
    }

    public static void main(String[] args) {
        int codigoProduto = 7; // Insira o código do produto aqui
        String classificacao = classificarProduto(codigoProduto);
        System.out.println("Classificação do produto: " + classificacao);
    }
}
