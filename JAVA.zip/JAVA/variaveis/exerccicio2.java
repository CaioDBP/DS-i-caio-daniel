/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios;

/**
 *
 * @author CAMARGO
 */
import java.util.Scanner;

public class exerccicio2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite a distância total percorrida (em km): ");
        double distanciaTotal = entrada.nextDouble();

        System.out.print("Digite o total de combustível gasto (em litros): ");
        double totalCombustivel = entrada.nextDouble();

        // Cálculo do consumo médio
        double media = totalCombustivel / distanciaTotal;

        System.out.println("O consumo médio foi de " + media + " litros por km.");
    }
}
