/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios;

/**
 *
 * @author CAMARGO
 */

 import java.util.Scanner;

public class exercicio8 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Digite o número total de eleitores: ");
        int totalEleitores = scanner.nextInt();

        System.out.println("Digite o número de votos brancos: ");
        int votosBrancos = scanner.nextInt();

        System.out.println("Digite o número de votos nulos: ");
        int votosNulos = scanner.nextInt();

        System.out.println("Digite o número de votos válidos: ");
        int votosValidos = scanner.nextInt();

        double percentualBrancos = (double) votosBrancos / totalEleitores * 100;
        double percentualNulos = (double) votosNulos / totalEleitores * 100;
        double percentualValidos = (double) votosValidos / totalEleitores * 100;

        System.out.println("Percentual de votos brancos: " + percentualBrancos + "%");
        System.out.println("Percentual de votos nulos: " + percentualNulos + "%");
        System.out.println("Percentual de votos válidos: " + percentualValidos + "%");

        
    }
}
