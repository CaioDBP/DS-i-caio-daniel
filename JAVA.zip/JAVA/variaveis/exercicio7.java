/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios;

/**
 *
 * @author CAMARGO
 */
import java.util.Scanner;

public class exercicio7 {
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);

        
        System.out.println("Digite a idade em anos: ");
        int anos = entrada.nextInt();

        System.out.println("Digite a idade em meses: ");
        int meses = entrada.nextInt();

        System.out.println("Digite a idade em dias: ");
        int dias = entrada.nextInt();

        int idadeEmDias = anos * 365 + meses * 30 + dias;
        
        System.out.println("A idade em dias é: " + idadeEmDias);

        
    }
}
