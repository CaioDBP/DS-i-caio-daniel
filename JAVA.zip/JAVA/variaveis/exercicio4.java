/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios;

/**
 *
 * @author CAMARGO
 */
import java.util.Scanner;
public class exercicio4 {
    public static void main(String[] args){
        
    Scanner entrada = new Scanner (System.in);
    System.out.print("Qual a altura do seu retangulo:");
    double  altura = entrada.next.Double();
    
    System.out.print("Qual base do seu retangulo");
     double base = entrada.next.Double();
    
     double area = base*altura;
     System.out.print("A area do seu retangulo é igual a:"+area);
    
}
}