/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios;

/**
 *
 * @author CAMARGO
 */
import java.util.Scanner;

public class exercicio5 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Qual o consumo médio de combustível do seu carro (Km): ");
        double consumo = entrada.nextDouble();

        System.out.println("Qual a distância percorrida (Km): ");
        double distancia = entrada.nextDouble();

        System.out.println("Qual o preço  do combustivel(L): ");
        double precoCombustivel = entrada.nextDouble();

        
        double quantidadeCombustivel = distancia / consumo;

        // Calcular o custo estimado com combustível
        double custoCombustivel = quantidadeCombustivel * precoCombustivel;

    
        System.out.println("Provavel valor a pagar: R$" + custoCombustivel);

        
    }
}
