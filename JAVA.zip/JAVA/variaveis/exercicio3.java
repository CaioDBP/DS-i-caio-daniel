/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicios;

/**
 *
 * @author CAMARGO
 */
import java.util.Scanner;

public class exercicio3 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Qual seu nome: ");
        String nome = entrada.nextLine();
        
        System.out.print("Qual valor total das suas vendas:");
        double vendas = entrada.nextDouble();
        
        System.out.print("Qual valor do seu salario:");
        double salario = entrada.nextDouble();
        
        double salarioreform = vendas * 0.15 + salario;
        System.out.print("Caro senhor(a)"+nome+",seu salario fixo é:"+salario+ ", mas com o reajuste ele fica:"+salarioreform);
        
}
}